//objects
var fish;
var shark;
var eel;
var bait = [];

//key binds
var w = 87; 
var a = 65;
var d = 68;
var s = 83;

//sound effects
var correctSound = new Audio("sounds/correct.wav");
var incorrectSound  = new Audio("sounds/incorrect.wav");

var current = -1;
var numText = 10;
var score = 0;

var gameState = 0;
var tw;

var globalSpeed = 1;

function setup() {
	createCanvas (1280,720);
	frameRate(60);
}

function initGame() {
	background(color(160, 221, 250));
	gameState = 0;
	textSize(150);
	var title = "PHISH GAME";
	fill(255);
	tw = textWidth(title);
	text(title, (width - tw)/2, height/2 - 40);
	startBtn = createButton('Start Game');
	startBtn.position(width/2 - startBtn.width/2, height/2);
	startBtn.mousePressed(levelSelect);
	noLoop();
}

function resetAll(){
	
}

function levelSelect() {
	startBtn.hide();
	gameState = 1;
	background(color(160, 221, 250));
	textSize(150);
	title = "LEVEL SELECT";
	fill(255);
	tw = textWidth(title);
	text(title, (width - tw)/2, height/2 - 40);
	levelStart = createButton('Level 1');
	levelStart.position(width/2 - levelStart.width/2, height/2);
	levelStart.mousePressed(setupGame);
	noLoop();
}

function levelSelect2() {
	levelStart.hide();
	gameState = 1;
	background(color(160, 221, 250));
	textSize(150);
	title = "LEVEL SELECT";
	fill(255);
	tw = textWidth(title);
	text(title, (width - tw)/2, height/2 - 40);
	levelStart = createButton('Level 1');
	levelStart.position(width/2 - levelStart.width/2, height/2);
	levelStart.mousePressed(setupGame);
	noLoop();
}

function setupGame(){
	levelStart.hide();
	score = 0;
	life = 3;
	bait = [];
	gameState = 2;
	fish = new Fish();
	shark = new Enemy(0);
	eel = new Enemy(1);
	for (var i=0; i<10; i++) {
		bait.push(new Bait(floor(random(numText - 1))));
	}
	loop();
}

function endScreen(win){
	background(color(160, 221, 250));
	textSize(150);
	if (win) {
		title = "Congratulation";
	} else if (!win) title = "You lose";
	fill(255);
	tw = textWidth(title);
	text(title, (width - tw)/2, height/2 - 40);
	levelStart = createButton('Play Again');
	levelStart.position(width/2 - levelStart.width/2, height/2);
	levelStart.mousePressed(levelSelect2);
	noLoop();
}


function game() {
	background(color(160, 221, 250));
	textSize(20);
	text(score,10,30);
	text(fish.life,640,30);
	//bait
	if (frameCount % 10000 == 0) {
		globalSpeed = globalSpeed + 1;
	}
	
	for (var i= bait.length - 1; i >= 0; i--) {
		bait[i].update();
		if (bait[i].eaten == false) {
			bait[i].show();
		}
		//if (bait[i].incorrect == true) {
			//bait[i].show();
		//}
		
		if  (!bait[i].hits(fish) && bait[i].eaten == false && fish.selected == true) {
			fish.off();
		} else if (bait[i].hits(fish) && bait[i].eaten == false && fish.selected == false && bait[i] && bait[i].incorrect == false){
			textSize(20);
			text(bait[i].texts[bait[i].index], 10, 60);
			text(bait[i].isBait[bait[i].index], 10, 90);
			current = i;
			fish.on();  
		}
		if (bait[i].offscreen()) { //removes when off screen
				if (bait[i].isBait[bait[i].index] == false && bait[i].eaten == false) {
					score += 100;
					correctSound.play();
				} else if (bait[i].isBait[bait[i].index] == true && bait[i].eaten == false){
					score -= 100;
					fish.takeDmg();
					incorrectSound.play();
				}
				bait.splice(i,1);
				bait.push(new Bait(floor(random(numText - 1))));
		}
		if (shark.hits(fish)) {
			fish.takeDmg();
		}
		if (eel.hits(fish)) {
			fish.takeDmg();
		}
		
		bait[i].incSpeed(globalSpeed);
	}
	
	//fish
	fish.update();
	fish.show();
	
	//shark enemy
	//shark.update(fish);
	//shark.show();
	
	//eel
	//eel.update(fish);
	//eel.show();
	
	if (keyIsDown(w) && keyIsDown(d)){ 
		fish.upRight();
	}
	if (keyIsDown(w) && keyIsDown(a)){
		fish.upLeft();
	}
	if (keyIsDown(s) && keyIsDown(d)){
		fish.downRight();
	}
	if (keyIsDown(s) && keyIsDown(a)){
		fish.downLeft();
	}
	
	if (keyIsDown(w) && (!keyIsDown(a) || !keyIsDown(d))) {
		fish.up();
	}
	if (keyIsDown(s) && (!keyIsDown(a) || !keyIsDown(d))) {
		fish.down();
	}
	if (keyIsDown(a) && (!keyIsDown(w) || !keyIsDown(s))) {
		fish.left();
	}
	if (keyIsDown(d)&& (!keyIsDown(w) || !keyIsDown(s))) {
		fish.right();
	}
	
	if (score >= 1000) {
		endScreen(true);
	}else if( fish.life <= 0) {
		endScreen(false);
	}
	
}

function draw() {
	if (gameState == 0) {//main menu
		initGame();
	}
	else if (gameState == 1) {
		levelSelect();
	}
	else if (gameState == 2) {//in game
		game();//level
	}
	else if (gameState == 3) {
		if (score >= 1000) {
			endScreen(true);
		}else if( fish.life <= 0) {
			endScreen(false);
		}
	}
}

function keyTyped () {
	if (key == ' ') { 
		if (bait[current].hits(fish) && bait[current].eaten == false) {
			bait[current].gotEaten();
			if (bait[current].isBait[bait[current].index] == true){
				score += 100;
				correctSound.play();
			} else {
				score -= 100;
				fish.takeDmg() ; //eat bait
				incorrectSound.play();
				bait[current].crash();
			}
		}
	}
}